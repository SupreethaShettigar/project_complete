package grocery;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

@Entity(name = "carts")
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer cartid;
	
	private Integer uqty;
	private Float total;
	private String status;

	
	@Transient
	private Integer fk;
	
	@Transient
	private Integer pfk;
	
	@ManyToOne
	private User user;
	
	@ManyToOne
	private Product product;
	
	
	public Cart()
	{
		
	}


	public Integer getCartid() {
		return cartid;
	}


	public void setCartid(Integer cartid) {
		this.cartid = cartid;
	}


	public Integer getUqty() {
		return uqty;
	}


	public void setUqty(Integer uqty) {
		this.uqty = uqty;
	}


	public Float getTotal() {
		return total;
	}


	public void setTotal(Float total) {
		this.total = total;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public Integer getFk() {
		return fk;
	}


	public void setFk(Integer fk) {
		this.fk = fk;
	}


	public Integer getPfk() {
		return pfk;
	}


	public void setPfk(Integer pfk) {
		this.pfk = pfk;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}


	public Cart(Integer cartid, Integer uqty, Float total, String status, Integer fk, Integer pfk) {
		super();
		this.cartid = cartid;
		this.uqty = uqty;
		this.total = total;
		this.status = status;
		this.fk = fk;
		this.pfk = pfk;
	}


	public Cart(Integer cartid, Integer uqty, Float total, String status, Integer fk, Integer pfk, User user,
			Product product) {
		super();
		this.cartid = cartid;
		this.uqty = uqty;
		this.total = total;
		this.status = status;
		this.fk = fk;
		this.pfk = pfk;
		this.user = user;
		this.product = product;
	}
	
	
	
	
	
	
	
}

export class Cart {
    pid: number
    uid: number
    cid: number
    uqty: number
    total: number
    status: string
    fk:number
    pfk:number
    
    constructor() {
        this.pid = 0
        this.cid = 0
        this.uqty=0
        this.total=0
        this.status=''
        this.fk=0,
        this.pfk=0
       
    }
}

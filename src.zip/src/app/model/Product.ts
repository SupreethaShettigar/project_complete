export class Product {
    pid: number
    pname: string
    pqty: number
    uqty: number
    unit: string
    price: number
    imageUrl: String
    cfk: number
    cid: number
    
    constructor() {
        this.pid = 0
        this.pname = ''
        this.pqty = 0
        this.uqty = 0
        this.unit = ''
        this.imageUrl = ''
        this.price = 0
        this.cfk = 0
        this.cid = 0
    }
}

import { Component, OnInit } from '@angular/core';
import { Router, Event, NavigationEnd } from '@angular/router';
import { Cart } from './../model/Cart';
import { Order } from './../model/Order';
import { Status } from './../model/Status';
import { AuthenticateService } from '../authenticate.service';
import { CartService } from './../cart.service';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart:Cart
  carts:Cart[]
  order:Order
  progressFlag: boolean
  constructor( public cartService: CartService,public authService: AuthenticateService,public router: Router) {
this.order=new Order()
  this.cart=new Cart()
   this.carts=this.cartService.carts 
   }



   deleteCartItem(cartid, index) {
    this.cartService.deleteCartItem(cartid)
      .subscribe((res: Status) => {
        if (res.queryStatus)
          this.carts.splice(index, 1)
      })
  }

  ngOnInit() {
  }

  placeOrder(id,index)
  {
this.cartService.carts[index].status="true"
this.order.ufk=this.authService.currentUser.id
this.order.oid=0
this.order.total=this.cartService.carts[index].total
this.cartService.placeOrder(this.order)
      .subscribe((res: Order) => {

        if (res !== null) {
          
          
          this.router.navigateByUrl('/cart')
        }
        else {
          
        }
      }, err => {
        console.log(err)
       

      })

  }
}
